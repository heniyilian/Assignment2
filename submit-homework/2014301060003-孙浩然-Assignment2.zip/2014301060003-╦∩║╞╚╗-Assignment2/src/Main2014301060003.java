import java.io.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class Main2014301060003 {

	public static void main(String[] args) {
		Main2014301060003 main = new Main2014301060003();
		//main.crawlhtml();
		File input = new File("teacher.html");
		try {
			File output = new File("teacher.txt");
			FileWriter fw = new FileWriter(output,true);
			
			//read html
			Document doc = Jsoup.parse(input,"UTF-8","");
			Elements details = doc.select("div.page-content");
			Element detail =details.first();
		    String detailText = detail.text();
		    fw.write(detailText);
		    
		    //regex
			fw.write("\r\n\r\n��������������");
			Pattern pSplit = Pattern.compile("[, |]+");
			String[] strs = pSplit.split(detailText);
			Pattern pEmail = Pattern.compile("^([a-zA-Z0-9_\\-\\.]+)@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.)|(([a-zA-Z0-9\\-]+\\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\\]?)$");
			Pattern pPhone = Pattern.compile("^1[0-9]{10}$");
			Matcher matcher = null;
			for (int i=0;i<strs.length;i++) {
				matcher = pEmail.matcher(strs[i]);
				if(matcher.matches()) {
					fw.write("\r\n���䣺");
					fw.write(strs[i]);
					continue;
				}
				matcher = pPhone.matcher(strs[i]);
				if(matcher.matches()) {
					fw.write("\r\n�绰���룺");
					fw.write(strs[i]);
				}
			} 
			
			fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void crawlhtml() {
        String url = "http://staff.whu.edu.cn/show.jsp?lang=cn&n=Xing%20_%20Jun";
		
		HttpRequest teacher = HttpRequest.get(url);
		
		teacher.header("cookie","JSESSIONID=01B072ACEDB3160D19FF8AF8D5A914A4");
		
		if(teacher.ok())
		{
			teacher.receive(new File("teacher.html")); 
		}
	}
}
